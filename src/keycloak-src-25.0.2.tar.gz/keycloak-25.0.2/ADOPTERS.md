ADOPTERS
========

PUBLIC REFERENCES
-----------------

List of organization names below is based on information collected using Keycloak Community Survey. It contains company names from participants who agreed to serve as public reference. If organizations would like get added or removed please make a PR. 

* Accenture
* Actinver
* Akvo Foundation
* AlmaLinux Foundation
* Appier
* Associazione Rousseau
* BISPRO
* Bluestem Brands, Inc
* Bundesagentur für Arbeit
* Bundesversicherungsamt
* Capgemini
* CERN (European Organisation for Nuclear Research)
* Chassi
* CloudNative Inc.
* Conciso GmbH
* Copenhagen Optimization
* Curecomp GmbH
* Cybertech
* Devsu
* Devoxx / Voxxed
* DUENE e.V - project 
* DukeCon
* European Synchrotron Radiation Facility
* Fluance AG
* Genchi Genbutsu SRL
* Hewlett-Packard Enterprise
* Hitachi
* INEAT
* Inventage
* ISAAC
* ITROI Solutions
* Kindly Ops, LLC
* [Microcks](https://landscape.cncf.io/?selected=microcks)
* msg systems ag
* Netdava International
* Ohio Supercomputer Center
* Okta
* PharmaPartners B.V.
* Plivo
* Price Insight
* Prodesan
* Quest Software
* Research Industrial Software Engineering (RISE)
* Sportsbet.com.au
* Stack Labs
* Storebrand
* Synekus
* Synetek Solutions
* Taklane
* TrackingSport
* TRT9 - Brasil
* UnitedHealthcare
* Wayfair LLC
* ...More individuals
